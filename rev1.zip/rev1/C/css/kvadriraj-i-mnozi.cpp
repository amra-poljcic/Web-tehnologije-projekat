#include<iostream>
#include<vector>
#include<cmath>
void ispisiSve(int n,int PoModulu){
    std::cout<<1<<" "<<n<<std::endl;
    for(int i=2;i<12;i++){
        std::cout<<pow(2,i-1)<<" "<<(n*n)%PoModulu<<std::endl;
        n=(n*n)%PoModulu;
    }
}
int ostatak(int a,int b,int c, int d, int modul){
    int x = (a*b)%modul;
    int y = (c*d)%modul;
    return (x*y)%modul;
}
int ostatak2(int a,int b,int c, int modul){
    int x = (a*b)%modul;
    return (x*c)%modul;
}
int main(){
    ispisiSve(509,953);
    //std::cout<<"Ukupni ostatak je: "<<ostatak(489,924,784,925,953);
std::cout<<"Ukupni ostatak je: "<<ostatak2(331,632,118,953);
    return 0;
}