// zadatak 1

let PoziviRezervacija = new Pozivi();
let popunioZauzeca = false;

var podaci_periodicni = [];
var podaci_vanredni = [];

function popuniZauzeca(p_P, p_V) {
    podaci_periodicni = p_P;
    podaci_vanredni = p_V;
    popunioZauzeca = true;
    // na neki način ovdje odradi update samo i sve će raditi.
    Kalendar.updateujTabelu();
}

PoziviRezervacija.dajZauzeca(popuniZauzeca);

function provjeriZauzetostFrontend(x) {
    return x.nextSibling.className == "slobodna";
}

function celijaBrojClick(e){
    if(provjeriZauzetostFrontend(e.target)) {
        let result = confirm("Kliknite OK da rezervišete salu!");
        if (result) {
            // ajaxPoziv pošalji ovdje i obradi podatke

            let mjesecSlovima = document.getElementsByClassName('mjesec')[0].innerHTML;
            console.log(mjesecSlovima);
            let trenutniMjesec;
            
            if(mjesecSlovima == "Januar") trenutniMjesec = 1;
            else if(mjesecSlovima == "Februar") trenutniMjesec = 2;
            else if(mjesecSlovima == "Mart") trenutniMjesec = 3;
            else if(mjesecSlovima == "April") trenutniMjesec = 4;
            else if(mjesecSlovima == "Maj") trenutniMjesec = 5;
            else if(mjesecSlovima == "Juni") trenutniMjesec = 6;
            else if(mjesecSlovima == "Juli") trenutniMjesec = 7;
            else if(mjesecSlovima == "August") trenutniMjesec = 8;
            else if(mjesecSlovima == "Septembar") trenutniMjesec = 9;
            else if(mjesecSlovima == "Oktobar") trenutniMjesec = 10;
            else if(mjesecSlovima == "Novembar") trenutniMjesec = 11;
            else if(mjesecSlovima == "Decembar") trenutniMjesec = 12;

            // izvuci iz trenutnog mjeseca na tabeli
            // izvuci još i ime sale document.getElementById...
            // također i za sate....

            noviObjekat = {
                datum: e.target.innerText + "." + trenutniMjesec + ".2019.",
                pocetak: document.querySelector("#pocetak").value,
                kraj: document.querySelector("#kraj").value,
                naziv: document.querySelector("#sala").value,
                predavac: "HF"
            }

            PoziviRezervacija.upisiZauzece(noviObjekat, popuniZauzeca);
        }
    }
    else {

         let mjesecSlovima = document.getElementsByClassName('mjesec')[0].innerHTML;
        
         let trenutniMjesec;

         if(mjesecSlovima == "Januar") trenutniMjesec = 1;
         else if(mjesecSlovima == "Februar") trenutniMjesec = 2;
         else if(mjesecSlovima == "Mart") trenutniMjesec = 3;
         else if(mjesecSlovima == "April") trenutniMjesec = 4;
         else if(mjesecSlovima == "Maj") trenutniMjesec = 5;
         else if(mjesecSlovima == "Juni") trenutniMjesec = 6;
         else if(mjesecSlovima == "Juli") trenutniMjesec = 7;
         else if(mjesecSlovima == "August") trenutniMjesec = 8;
         else if(mjesecSlovima == "Septembar") trenutniMjesec = 9;
         else if(mjesecSlovima == "Oktobar") trenutniMjesec = 10;
         else if(mjesecSlovima == "Novembar") trenutniMjesec = 11;
         else if(mjesecSlovima == "Decembar") trenutniMjesec = 12;
            

        //let nazivSale = document.getElementsByClassName('listaSala');
        var nazivSale = document.getElementById("sala");
        var vrijednost = nazivSale.options[nazivSale.selectedIndex].value;
        var text = nazivSale.options[nazivSale.selectedIndex].text;

        var pocetnoVrijeme = document.getElementById("pocetak").value;
        var kranjeVrijeme = document.getElementById("kraj").value;


        alert('Nije moguće rezervisati salu ' + text + ' za navedeni datum ' + e.target.innerText + '/' + trenutniMjesec + '/2019 ' + 'i termin od ' + pocetnoVrijeme + ' do ' + kranjeVrijeme + '!');
    }
}

// stare funckije
function dajPeriodicna() {
    return podaci_periodicni;
}

function dajVanredna() {
    return podaci_vanredni;
}

function kojiMjesec(nekiMjesec) {
    var prva = nekiMjesec[3];
    var druga = nekiMjesec[4];
    return (parseInt(prva.concat(druga)));
}

function kojiDan(datumNeki) {
    var prva = datumNeki[0];
    var druga = datumNeki[1];
    return (parseInt(prva.concat(druga)));
}
