var express = require('express')
var bodyParser = require('body-parser');
var fs = require('fs');

var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('htmlovi'));

app.get('/zauzeca', function (req, res) {
    fs.readFile('zauzeca.json', function (err, content) {
        if (err) res.send('Desila se greška');
        res.send(JSON.parse(content));
    })
})

app.post('/rezervacija', function (req, res) {
    fs.readFile('zauzeca.json', function (err, content) {
        if (err) res.send('Desila se greška');

        let niz_zauzeca = JSON.parse(content);
        let niz_vanrednih = niz_zauzeca.vanredna;
        let niz_periodicnih = niz_zauzeca.periodicna;

        let bodyDatum = req.body.datum;
        let bodyPocetak = req.body.pocetak;
        let bodyKraj = req.body.kraj;
        let bodyNaziv = req.body.naziv;
        let bodyPredavac = req.body.predavac;

        let ima_ga = salaZauzeta(niz_vanrednih, bodyNaziv, bodyDatum, bodyPocetak, bodyKraj) || salaZauzeta(niz_periodicnih, bodyNaziv, bodyDatum, bodyPocetak, bodyKraj);

        if (ima_ga) {
            let x = {
                poruka: "Nije moguće rezervisati salu " + bodyNaziv + " za navedeni datum " + bodyDatum +
                    " i termin od " + bodyPocetak + " do " + bodyKraj + "!"
            };

            res.send(JSON.stringify(x));
        }

        else {
            let noviRed = {
                datum: bodyDatum,
                pocetak: bodyPocetak,
                kraj: bodyKraj,
                naziv: bodyNaziv,
                predavac: bodyPredavac
            }
            niz_vanrednih.push(noviRed);

            let noviObjektZaZauzeca = {
                periodicna: niz_periodicnih,
                vanredna: niz_vanrednih
            }

            fs.writeFile('zauzeca.json', JSON.stringify(noviObjektZaZauzeca), function (err) {
                if (err) res.send('Problemi pri upisivanju u fajl!');
                else {
                    res.send(noviObjektZaZauzeca);
                }
            })
        }
    })
})

app.get('/pocetna-slike', function (req, res) {
    const stranica = req.query.stranica || 0;
    const ukupnoStranica = Math.floor(slikeZaPocetnu.length / 3);
    const slike = slikeZaPocetnu.slice(3 * stranica, (3 * stranica) + 3);

    res.send({
        slike,
        stranica,
        ukupnoStranica,
    })
})

app.get('/zabiljezi-posjetu', function (req, res) {
    const address = req.connection.remoteAddress;
    const userAgent = req.headers["user-agent"];

    const statistika = JSON.parse(fs.readFileSync("posjete.json"));
    statistika.posjete.push({ address, userAgent });

    fs.writeFileSync("posjete.json", JSON.stringify(statistika));

    const sazetak = dajSazetuStatistiku(statistika);

    res.send(sazetak);
});

function dajSazetuStatistiku(statistika) {
    const UAParser = require("ua-parser-js");

    const vidjeno = [];
    let chrome = 0;
    let firefox = 0;

    for (unos of statistika.posjete) {
        const ua = UAParser(unos.userAgent);

        if (ua.browser.name == "Chrome") chrome++;
        if (ua.browser.name == "Firefox") firefox++;

        if (!vidjeno.includes(unos.address)) {
            vidjeno.push(unos.address);
        }
    }

    let sazetak = {
        posjeta: statistika.posjete.length,
        razlicitihIPAdresa: vidjeno.length,
        chrome,
        firefox,
    };

    return sazetak;
}

const slikeZaPocetnu = [
    "bulbasaur.png",
    "charmander.png",
    "jigglypuff.jpg",
    "lapras.png",
    "mew.jpg",
    "pidgeot.jpg",
    "pikachu.jpg",
    "snorlax.jpg",
    "squirtle.jpg",
    "togepi.jpg",
];

function salaZauzetaPeriodicno(podaci_periodicni, trenutnaSala, mjesec, dan, pocetak, kraj) {
    if (!podaci_periodicni) return false;

    var semestar = dajSemestar(mjesec);

    var unosi = podaci_periodicni.filter(function (periodicni_unos) {
        return trenutnaSala == periodicni_unos.naziv && semestar == periodicni_unos.semestar && dan == periodicni_unos.dan;
    });

    if (unosi.length <= 0) {
        return false;
    }

    return unosi.some(function (unos) {
        return intervalVremena(unos.pocetak, unos.kraj, pocetak, kraj);
    });
}

function salaZauzetaVanredno(podaci_vanredni, trenutnaSala, mjesec, dan, pocetak, kraj) {
    if (!podaci_vanredni) return false;

    var unosi = podaci_vanredni.filter(function (vanredni_unos) {
        var datum = dan + "." + (mjesec + 1) + ".2019.";
        return trenutnaSala == vanredni_unos.naziv && datum == vanredni_unos.datum;
    });

    if (unosi.length <= 0) {
        return false;
    }

    return unosi.some(function (unos) {
        return intervalVremena(unos.pocetak, unos.kraj, pocetak, kraj);
    });
}

function salaZauzeta(trenutnaSala, mjesec, dan, pocetak, kraj) {
    return salaZauzetaPeriodicno(trenutnaSala, mjesec, dan, pocetak, kraj) || salaZauzetaVanredno(trenutnaSala, mjesec, dan, pocetak, kraj)
};

function dajSemestar(mjesec) {
    if ([9, 10, 11, 0].includes(mjesec)) return "zimski";
    if ([1, 2, 3, 4, 5].includes(mjesec)) return "ljetnji";
}

function intervalVremena(salaPoc, salaKr, pocetak, kraj) {
    if (pocetak > salaPoc && pocetak < salaKr) {
        return true;
    }
    else if (pocetak < salaPoc && kraj > salaPoc) {
        return true;
    }
    else if (pocetak == salaPoc || kraj == salaKr) {
        return true;
    }
    return false;
}

app.listen(8080);
