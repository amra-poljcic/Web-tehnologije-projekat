var godina = 2020;
var trenutniMjesec = 0;

function bojenjeZauzeca(){
    var saleSelektor = document.getElementById("saleSelektor");
    var sala = saleSelektor.value;
    var pocetak = document.getElementsByTagName("input")[1].value;
    var kraj = document.getElementsByTagName("input")[2].value;
    if (pocetak != "" || kraj != "" || sala != ""){
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, sala, pocetak, kraj);
    }
}
function iscrtavanjeKalendara(){;
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
}
function iscrtavanjeSljedeceg(){
    trenutniMjesec++;
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    var saleSelektor = document.getElementById("saleSelektor");
    var sala = saleSelektor.value;
    var pocetak = document.getElementsByTagName("input")[1].value;
    var kraj = document.getElementsByTagName("input")[2].value;
    if (pocetak != "" && kraj != "" && sala != ""){
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, sala, pocetak, kraj);
    }
    if (trenutniMjesec === 11) document.getElementById("sljedeci").disabled  = true;
    else if (document.getElementById("prethodni").disabled  === true){
        document.getElementById("prethodni").disabled  = false;
    }
}
function iscrtavanjePrethodnog(){
    trenutniMjesec--;
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    var saleSelektor = document.getElementById("saleSelektor");
    var sala = saleSelektor.value;
    var pocetak = document.getElementsByTagName("input")[1].value;
    var kraj = document.getElementsByTagName("input")[2].value;
    if (pocetak != "" && kraj != "" && sala != ""){
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, sala, pocetak, kraj);
    }
    if (trenutniMjesec === 0) document.getElementById("prethodni").disabled  = true;
    else if (document.getElementById("sljedeci").disabled  === true){
        document.getElementById("sljedeci").disabled  = false;
    }
}