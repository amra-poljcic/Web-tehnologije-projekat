const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const url = require('url');
const useragent = require('express-useragent');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/json'));
app.use('/galerija', express.static(__dirname + '/public/galerija'));
app.use(useragent.express());

app.get('/', function(req, res){
    res.sendFile(__dirname + '/public/pocetna.html');
});

app.get('/sale.html', function(req, res){
    res.sendFile(__dirname + '/sale.html');
});

app.get('/unos.html', function(req, res){
    res.sendFile(__dirname + '/unos.html');
});

app.get('/rezervacija.html', function(req, res){
    res.sendFile(__dirname + '/rezervacija.html');
});

app.get('/pozivi.js', function(req, res){
    res.sendFile(__dirname + '/pozivi.js');
});

app.get('/json/zauzeca.json', function(req, res){
    res.sendFile(__dirname + '/json/zauzeca.json')
});

app.get('/kalendar.js', function(req, res){
    res.sendFile(__dirname + '/kalendar.js');
});

app.get('/kalendarPom.js', function(req, res){
    res.sendFile(__dirname + '/kalendarPom.js');
});

app.get('/rezervacija.js', function(req, res){
    res.sendFile(__dirname + '/rezervacija.js');
});

app.post('/zauzeca', function(req, res){
    let tijelo = req.body;
    let novoZauzece;
    let periodicno = false;
    if (tijelo['periodicno']){
        periodicno = true;
        novoZauzece = {
            "dan": tijelo['dan'],
            "semestar": tijelo['semestar'],
            "pocetak": tijelo['pocetak'],
            "kraj": tijelo['kraj'],
            "naziv": tijelo['naziv'],
            "predavac": tijelo['predavac']
        };
    }
    else {
        novoZauzece = {
            "datum": tijelo['datum'],
            "pocetak": tijelo['pocetak'], 
            "kraj": tijelo['kraj'], 
            "naziv": tijelo['naziv'], 
            "predavac": tijelo['predavac']
        };
    }
    fs.readFile('./json/zauzeca.json', (error, data) => {
        let noviJson = "";
        let podaci = JSON.parse(data);
        let noviPocetak = parseInt(novoZauzece["pocetak"].substring(0,2)) * 60 + parseInt(novoZauzece["pocetak"].substring(3,5));
        let noviKraj = parseInt(novoZauzece["kraj"].substring(0,2)) * 60 + parseInt(novoZauzece["kraj"].substring(3,5));
        let periodicnaZauzeca = podaci.periodicna;
        let novaPeriodicna = [];
        let novaVanredna = [];
        let imaIstoP1 = false;
        let imaIstoV1 = false;

        //prvo dodaj sva periodicna koja su bila u jsonu opet
        for (let i = 0; i < periodicnaZauzeca.length; i++){
            novaPeriodicna.push({
                "dan": periodicnaZauzeca[i].dan,
                "semestar": periodicnaZauzeca[i].semestar,
                "pocetak": periodicnaZauzeca[i].pocetak,
                "kraj": periodicnaZauzeca[i].kraj,
                "naziv": periodicnaZauzeca[i].naziv,
                "predavac": periodicnaZauzeca[i].predavac
            });
        }

        //ima li isto zauzece u periodicnim
        for (let i = 0; i < periodicnaZauzeca.length; i++){
            let pocetak = parseInt(periodicnaZauzeca[i].pocetak.substring(0,2)) * 60 + parseInt(periodicnaZauzeca[i].pocetak.substring(3,5));
            let kraj = parseInt(periodicnaZauzeca[i].kraj.substring(0,2)) * 60 + parseInt(periodicnaZauzeca[i].kraj.substring(3,5));
            if (periodicno){
                //ako je novo zauzece periodicno, ima li isto u periodicnim
                if (periodicnaZauzeca[i].dan == novoZauzece["dan"] && periodicnaZauzeca[i].semestar == novoZauzece["semestar"] && ((noviPocetak > pocetak && noviPocetak < kraj) || (noviKraj > pocetak && noviKraj < kraj) || (noviPocetak <= pocetak && noviKraj >= kraj)) && periodicnaZauzeca[i].naziv == novoZauzece["naziv"]){
                    imaIstoP1 = true;
                    break;
                }
            }
            else {
                //ako je novo zauzece vanredno, poklapa li se sa nekim periodicnim
                let datum = novoZauzece["datum"].split(".");
                let prviDani = [1,4,4,0,2,5,0,3,6,1,4,6];
                let mjesec = datum[1];
                let dan = ((parseInt(datum[0]) + parseInt(prviDani[mjesec-1])) % 7) - 1;
                if (dan == -1) dan = 6;
                let semestar = "";
                mjesec = parseInt(mjesec);
                if (mjesec == 1 || mjesec == 10 || mjesec == 11 || mjesec == 12){
                    semestar = "zimski";
                }
                else if (mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5 || mjesec == 6){
                    semestar = "ljetni";
                }

                if (periodicnaZauzeca[i].dan == dan && periodicnaZauzeca[i].semestar == semestar && ((noviPocetak > pocetak && noviPocetak < kraj) || (noviKraj > pocetak && noviKraj < kraj) || (noviPocetak <= pocetak && noviKraj >= kraj)) && periodicnaZauzeca[i].naziv == novoZauzece["naziv"]){
                    imaIstoV1 = true;
                    break;
                }
            }
        }
        let vanrednaZauzeca = podaci.vanredna;
        let imaIstoP2 = false;
        let imaIstoV2 = false;

        //prvo dodaj sva vanredna koja su bila u jsonu opet
        for (let i = 0; i < vanrednaZauzeca.length; i++){
            novaVanredna.push({
                "datum": vanrednaZauzeca[i].datum,
                "pocetak": vanrednaZauzeca[i].pocetak, 
                "kraj": vanrednaZauzeca[i].kraj, 
                "naziv": vanrednaZauzeca[i].naziv, 
                "predavac": vanrednaZauzeca[i].predavac
            });
        }

        //ima li isto zauzece u vanrednim
        for (let i = 0; i < vanrednaZauzeca.length; i++){
            let pocetak = parseInt(vanrednaZauzeca[i].pocetak.substring(0,2)) * 60 + parseInt(vanrednaZauzeca[i].pocetak.substring(3,5));
            let kraj = parseInt(vanrednaZauzeca[i].kraj.substring(0,2)) * 60 + parseInt(vanrednaZauzeca[i].kraj.substring(3,5));
            if (!periodicno){
                //ako je novo zauzece vanredno, poklapa li se sa nekim vanrednim
                if (vanrednaZauzeca[i].datum == novoZauzece["datum"] && ((noviPocetak > pocetak && noviPocetak < kraj) || (noviKraj > pocetak && noviKraj < kraj) || (noviPocetak <= pocetak && noviKraj >= kraj)) && vanrednaZauzeca[i].naziv == novoZauzece["naziv"]){
                    imaIstoV2 = true;
                    break;
                }
            }
            else {
                //ako je novo zauzece periodicno, poklapa li se sa nekim vanrednim
                let datum = vanrednaZauzeca[i].datum.split(".");
                let prviDani = [1,4,4,0,2,5,0,3,6,1,4,6];
                let mjesec = datum[1];
                let dan = ((parseInt(datum[0]) + parseInt(prviDani[mjesec-1])) % 7) - 1;
                if (dan == -1) dan = 6;
                let semestar = "";
                mjesec = parseInt(mjesec);
                if (mjesec == 1 || mjesec == 10 || mjesec == 11 || mjesec == 12){
                    semestar = "zimski";
                }
                else if (mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5 || mjesec == 6){
                    semestar = "ljetni";
                }
                if (dan == novoZauzece["dan"] && semestar == novoZauzece["semestar"] && ((noviPocetak > pocetak && noviPocetak < kraj) || (noviKraj > pocetak && noviKraj < kraj) || (noviPocetak <= pocetak && noviKraj >= kraj)) && vanrednaZauzeca[i].naziv == novoZauzece["naziv"]){
                   imaIstoP2 = true;
                   break;
                }
            }
        }

        //ako se zauzece ne poklapa ni sa jednim postojecim, sala se rezervise
        let greska = "";
        if (!imaIstoP1 && !imaIstoV1 && !imaIstoP2 && !imaIstoV2){
            if (periodicno) {
                novaPeriodicna.push(novoZauzece);
            }
            else {
                novaVanredna.push(novoZauzece);
            }  
        } 
        else {
            if (periodicno){
                var dani = ['ponedjeljak', 'utorak', 'srijedu', 'četvrtak', 'petak', 'subotu', 'nedjelju'];
                greska = "Nije moguće rezervisati salu " + novoZauzece["naziv"] + " za " + dani[novoZauzece["dan"]] + " u terminu od " + novoZauzece["pocetak"] + " do " + novoZauzece["kraj"] + "!";
            }
            else {
                greska = "Nije moguće rezervisati salu " + novoZauzece["naziv"] + " za navedeni datum " + novoZauzece["datum"] + " u terminu od " + novoZauzece["pocetak"] + " do " + novoZauzece["kraj"] + "!";
            }
        }    

        //upis u zauzeca.json
        noviJson = {periodicna: novaPeriodicna, vanredna: novaVanredna};  
        noviJson = JSON.stringify(noviJson);
        fs.writeFile('./json/zauzeca.json', noviJson, (err) => {
            if (err) res.render({greska: greska});
            res.end(noviJson);
        });
    })
});

app.get('/pocetna.js', function(req, res){
    res.sendFile(__dirname + "/pocetna.js")
});

app.get('/public/galerija/slika1.jpg', function(req, res){
    res.sendFile(__dirname + '/public/galerija/slika1.jpg');
});

app.post('/galerija', function(req, res){
    let prva = req.body.prvaUcitana;
    let treca = req.body.posljednjaUcitana;
    let ucitaneSveSlike = req.body.ucitaneSveSlike;
    let granica = treca;
    let nizSlika = [];
    let greska = "";
    fs.readdir(__dirname + '/public/galerija/', function(err, files){
        if (err) throw err;
        let brojSlika = files.length;
        if (parseInt(brojSlika) == 0){
            greska = "Greška: Galerija je prazna!";

        }
        else {
            if (treca >= brojSlika) {
                treca = brojSlika;
                granica = treca - 1;
            }
            if (treca <= brojSlika){
                for (let i = prva; i <= granica; i++){
                    if (treca <= brojSlika) {
                        nizSlika.push(files[i]);
                        app.get('/public/galerija/' + files[i], function(req, res){
                            res.sendFile(__dirname + '/public/galerija/' + files[i]);
                        });
                    }
                }
            }
        }
        let odgovor = {nizSlika: nizSlika, ucitaneSveSlike: ucitaneSveSlike, brojSlika: brojSlika, greska: greska};
        res.json(odgovor);
    });
});

app.get('/json/broj_posjetilaca.json', function(req, res){
    res.sendFile(__dirname + '/json/broj_posjetilaca.json');
});

app.post('/posjete', function(req, res){
    fs.readFile('./json/broj_posjetilaca.json', 'utf-8', (err, data) => {
        let novePosjete = "";
        
        let noveChrome = JSON.parse(data).posjeteChrome;
        let noveFirefox = JSON.parse(data).posjeteFirefox;
        let noveIPadrese = JSON.parse(data).razliciteIPadrese;

        let nova = true;
        if (toString(req.connection.remoteAddress) != "::1"){
            for (let i = 0; i < noveIPadrese.length; i++){
                if (toString(noveIPadrese[i]) == toString(req.connection.remoteAddress)){
                    nova = false;
                    break;
                }
            }
        }
        if (nova){
            noveIPadrese.push(req.connection.remoteAddress);
        }
        
        if (req.useragent.isChrome) {
            noveChrome++;
        }
        else if (req.useragent.isFirefox){
            noveFirefox++;
        }
        novePosjete = {posjeteChrome: noveChrome, posjeteFirefox: noveFirefox, razliciteIPadrese: noveIPadrese};
        novePosjete = JSON.stringify(novePosjete);
        
        
        fs.writeFile('./json/broj_posjetilaca.json', novePosjete, 'utf-8', (err) => {
            if (err) throw err; 
            res.end(novePosjete);
        });
    });
});

app.listen(8080, () => console.log("App listening on port 8080!"));
