let assert = chai.assert;
describe('Kalendar', function() {
    describe('iscrtajKalendar()', function() {
        it('Test 1: Broj dana u Septembru : ', function() {
            Kalendar.iscrtajKalendar(null,8);
            let dan = document.getElementsByClassName("datum");
            let dani = [];
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].innerHTML != "") dani.push(dan[i].innerHTML);
            }
            assert.equal(dani[dani.length-1], 30, "Dan treba biti 30");
        });
        it('Test 2: Broj dana u Decembru : ', function() {
            Kalendar.iscrtajKalendar(null,11);
            let dan = document.getElementsByClassName("datum");
            let dani = [];
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].innerHTML != "") dani.push(dan[i].innerHTML);
            }
            assert.equal(dani[dani.length-1], 31, "Dan treba biti 31");
        });
        it('Test 3: Prvi dan u Novembru : ', function() {
            Kalendar.iscrtajKalendar(null,10);
            let dan = document.getElementsByClassName("datum");
            let i = 0;
            while (dan[i].innerHTML == "") i++;
            assert.equal(dan[i].classList.contains("pet"), true, "Novembar pocinje u Petak");
        });
        it('Test 4: Zadnji dan u Novembru : ', function() {
            Kalendar.iscrtajKalendar(null,10);
            let dan = document.getElementsByClassName("datum");
            let i = dan.length-1;
            while (dan[i].innerHTML == "") i--;
            assert.equal(dan[i].classList.contains("sub"), true, "Novembar zavrsava u Subotu");
        });
        it('Test 5: Januar krece od Utorka : ', function() {
            Kalendar.iscrtajKalendar(null, 0);
            let dan = document.getElementsByClassName("datum");
            let i = 0;
            while (dan[i].innerHTML == "") i++;
            assert.equal(dan[i].classList.contains("uto"), true, "Januar pocinje u Utorak");
            assert.equal(dan[i].innerHTML, 1, "Prvi dan")
            i = dan.length-1;
            while (dan[i].innerHTML == "") i--;
            assert.equal(dan[i].innerHTML, 31, "Januar ima 31 dan")
        });
        it('Test 6: Februar ima 28 dana : ', function() {
            Kalendar.iscrtajKalendar(null, 1);
            let dan = document.getElementsByClassName("datum");
            let i = dan.length-1;
            while (dan[i].innerHTML == "") i--;
            assert.equal(dan[i].innerHTML, 28, "Februar ima 28 dana")
        });
        it('Test 7: April pocinje u Ponedeljak : ', function() {
            Kalendar.iscrtajKalendar(null, 3);
            let dan = document.getElementsByClassName("datum");
            let i = 0;
            while (dan[i].innerHTML == "") i++;
            assert.equal(dan[i].classList.contains("pon"), true, "April pocinje u Ponedeljak")
        });
    });
    describe('obojiZauzeca()', function() {
        it('Test 1: Podaci nisu ucitani : ', function() {
            podaci = Kalendar.ucitajPodatke([],[]); //Prazni ucitane podatke
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                assert.equal(dan[i].classList.contains("red"), false, "Sve sale trebaju biti slobodne");
            }
        });
        it('Test 2: Preklapanje termina : ', function() {
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 0, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 0, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],[]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].classList.contains("pon") && dan[i].innerHTML != "") 
                    assert.equal(dan[i].classList.contains("red"), true, "Sale trebaju biti zauzete");
            }
        });
        it('Test 3: Periodicno zauzece sljedeceg semestra : ', function() {
            //U odnosu na trenutni mjesec
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 0, 
                    semestar: "ljetni", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 0, 
                    semestar: "ljetni", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],[]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                assert.equal(dan[i].classList.contains("red"), false, "Sale trebaju biti slobodne");
            }
        });
        it('Test 4: Zauzece u drugom mjesecu : ', function() {
            //Vanredno zauzece u odnosu na ne-trenutni mjesec
            podaci = Kalendar.ucitajPodatke([],[
                {
                    datum: "13.08.2019",
                    pocetak: "10:00",
                    kraj: "13:00",
                    naziv: "0-01",
                    predavac: "Vedran Ljubovic"
                }
            ]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                assert.equal(dan[i].classList.contains("red"), false, "Sale trebaju biti slobodne");
            }
        });
        it('Test 5: Periodicno zauzece svih termina : ', function() {
            //U odnosu na trenutni mjesec
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 0, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 1, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }, 
                {
                    dan: 2, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 3, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 4, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 5, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 6, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],[]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].innerHTML != "") assert.equal(dan[i].classList.contains("red"), true, "Sale trebaju biti zauzete");
            }
        });
        it('Test 6: Bojenje vise puta : ', function() {
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 0, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],[]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].classList.contains("pon") && dan[i].innerHTML != "") 
                    assert.equal(dan[i].classList.contains("red"), true, "Sale trebaju biti zauzete");
            }
        });
        it('Test 7: Ucitaj, oboji, ucitaj, oboji : ', function() {
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 1, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],[]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 4, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],[]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].classList.contains("uto") && dan[i].innerHTML != "") 
                    assert.equal(dan[i].classList.contains("red"), false, "Sale trebaju biti slobodne utorkom");
                if(dan[i].classList.contains("pet") && dan[i].innerHTML != "") 
                    assert.equal(dan[i].classList.contains("red"), true, "Sale trebaju biti zauzete petkom");
            }
        });
        it('Test 8: Vanredni i periodicni termin isti dan : ', function() {
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 1, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],[
                {
                    datum: "16.11.2019",
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ]);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].classList.contains("uto") && dan[i].innerHTML != "") 
                    assert.equal(dan[i].classList.contains("red"), true, "Sale trebaju biti zauzete petkom");
            }
        });
        it('Test 9: Periodicni termin vikendom : ', function() {
            podaci = Kalendar.ucitajPodatke([
                {
                    dan: 5, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                },
                {
                    dan: 6, 
                    semestar: "zimski", 
                    pocetak: "12:00", 
                    kraj: "14:00", 
                    naziv: "0-01", 
                    predavac: "Zeljko Juric"
                }
            ],
            []);
            Kalendar.obojiZauzeca(null, trenutni_mjesec, "0-01", null, null);
            let dan = document.getElementsByClassName("datum");
            for (let i = 0; i < dan.length; i++) {
                if((dan[i].classList.contains("sub") || dan[i].classList.contains("ned")) && dan[i].innerHTML != "") 
                    assert.equal(dan[i].classList.contains("red"), true, "Sale trebaju biti zauzete petkom");
            }
        });
    });
});


