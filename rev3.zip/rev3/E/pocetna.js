//URL slika za ucitavanje
let url1 = '/img/bobber.jpeg';
let url2 = '/img/bolt.jpg';
let url3 = '/img/bonevile.jpeg';
let url4 = '/img/goldwing.jpg';
let url5 = '/img/gs.jpeg';
let url6 = '/img/h2r.jpg';
let url7 = '/img/iron.jpeg';
let url8 = '/img/rebel.jpg';
let url9 = '/img/scout.jpeg';
let url10 = '/img/ural.jpg';
let broj = 0;

//Ucitavanje prve tri slike pomocu ajax poziva
$(document).ready(function () {
    Pozivi.ucitajSlike(url1, url2, url3);
    broj++;
});

//Ucitavanje sljedecih pomocu ajax poziva
//Ako se klikne na prethodni pa sljedeci slike se opet ucitavaju pomoc ajaxa jer postavka zadatka to trazi
function sljedece_slike() {
    if(broj < 4) broj++;
    else return false;
    if(broj == 2) Pozivi.ucitajSlike(url4, url5, url6);
    if(broj == 3) Pozivi.ucitajSlike(url7, url8, url9);
    if(broj == 4) {
        Pozivi.ucitajSlike(url10, '', '');
        $("#druga").hide();
        $("#treca").hide();
    }
    return false;
}

//Ucitavanje prethodnih slika bez ajax poziva
function prethodne_slike() {
    if(broj > 1) broj--;
    else return false;
    if (broj == 1) {
        $("#prva").attr("src", url1).fadeIn();
        $("#druga").attr("src", url2).fadeIn();
        $("#treca").attr("src", url3).fadeIn();
    }

    if (broj == 2) {
        $("#prva").attr("src", url4).fadeIn();
        $("#druga").attr("src", url5).fadeIn();
        $("#treca").attr("src", url6).fadeIn();
    }
    if (broj == 3) {
        $("#prva").attr("src", url7).fadeIn();
        $("#druga").attr("src", url8).fadeIn();
        $("#druga").show();
        $("#treca").show();
        $("#treca").attr("src", url9).fadeIn();
    }
    return false;
}
