const express = require("express");
const app = express();
const fs = require('fs');

//Obavezno pokretanje 'npm install' u terminalu prije pokretanja node index.js
//node_modules folder ne ide na git pa se dependencies moraju instalirat

//Omogucava upotrebu potrebnih fajlova
app.use(express.static(__dirname));

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/pocetna.html");
});

//Postavka zadatka trazi da se zauzeca mogu vratiti 
app.get("/zauzeca", function (req, res) {
    res.sendFile(__dirname + "/zauzeca.json");
});

app.get("/rezervacije", function (req, res) {
    res.sendFile(__dirname + "/rezervacije.html");
});

//Obrada POST zahtjeva za upis u zauzeca
app.post("/rezervacije.html", function (req, res) {
    let podaci = '';
    req.on('data', function (data) {
        podaci += data;
    })
    req.on('end', function () {
        let newObj = JSON.parse(podaci);
        let periodicnost = newObj["periodicnost"];
        delete newObj["periodicnost"];
        fs.readFile(__dirname + "/zauzeca.json", function (err, fileData) {
            if (err) {
                res.status(500).end();
            }
            else {
                let json = JSON.parse(fileData);
                let slobodna = true;

                //Serverska provjera zauzeca - zahtijev zadatka (moglo se i bez ovog...)
                json["vanredna"].forEach(element => {
                    if (element["datum"] == newObj["datum"] && element["naziv"] == newObj["naziv"]) {
                        if (!((parseInt(element["pocetak"]) <= parseInt(newObj["pocetak"]) && parseInt(element["kraj"]) <= parseInt(newObj["pocetak"])) ||
                            (parseInt(element["pocetak"]) >= parseInt(newObj["kraj"]) && parseInt(element["kraj"]) >= parseInt(newObj["kraj"])))) {
                            res.status(500).end();
                            slobodna = false;
                        }
                    }
                });

                json["periodicna"].forEach(element => {
                    if (element["naziv"] == newObj["naziv"]) {
                        let datum = new Date(parseInt(newObj["datum"].slice(6)), parseInt(newObj["datum"].slice(3, 5)) - 1, parseInt(newObj["datum"].slice(0, 3)));
                        if (parseInt(element["dan"]) + 1 == parseInt(datum.getDay())) {
                            if
                                (
                                (element["semestar"] == "zimski" && (parseInt(newObj["datum"].slice(3, 5)) - 1 == 0 || parseInt(newObj["datum"].slice(3, 5)) - 1 > 8)) ||
                                (element["semestar"] == "ljetni" && (parseInt(newObj["datum"].slice(3, 5)) - 1 >= 1 && parseInt(newObj["datum"].slice(3, 5)) - 1 <= 5))

                            ) {
                                if (!((parseInt(element["pocetak"]) <= parseInt(newObj["pocetak"]) && parseInt(element["kraj"]) <= parseInt(newObj["pocetak"])) ||
                                    (parseInt(element["pocetak"]) >= parseInt(newObj["kraj"]) && parseInt(element["kraj"]) >= parseInt(newObj["kraj"])))) {
                                    res.status(500).end();
                                    slobodna = false;
                                }
                            }
                        }
                    }
                });

                if (slobodna) {
                    //Ako nije ni zmiski ni ljetni semestar zauzece mora biti vanredno - dodatni komentar asistenta
                    let datum = new Date(parseInt(newObj["datum"].slice(6)), parseInt(newObj["datum"].slice(3, 5)) - 1, parseInt(newObj["datum"].slice(0, 3)));
                    if (!periodicnost || (datum.getMonth() >= 5 && datum.getMonth() <=7)) {
                        json["vanredna"].push(newObj);
                        fs.writeFile(__dirname + "/zauzeca.json", JSON.stringify(json), function () {
                            if (err) res.status(500).end();
                            else res.status(200).end();
                        }
                        )
                    } else {
                        let semestar = "zimski";
                        if (datum.getMonth() >= 1 && datum.getMonth() <= 5) semestar = "ljetni";
                        let obj = { dan: (datum.getDay() - 1) % 7, semestar: semestar, pocetak: newObj["pocetak"], kraj: newObj["kraj"], naziv: newObj["naziv"], predavac: newObj["predavac"] }
                        json["periodicna"].push(obj);
                        fs.writeFile(__dirname + "/zauzeca.json", JSON.stringify(json), function () {
                            if (err) res.status(500).end();
                            else res.status(200).end();
                        }
                        )
                    }
                }
            }
        });
    })
});

//Prikaz greske za nepostojece putanje
app.get(/[a-z]*/, function (req, res) {
    res.send("Error 404 - page not found");
});

app.listen(8080);
console.log("Server on port 8080");