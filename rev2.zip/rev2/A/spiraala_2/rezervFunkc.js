var kalendar = document.getElementsByClassName("kalendar")[0];
var sale = document.getElementsByName("sale")[0];
var periodicna = document.getElementsByName("periodicna")[0];
var pocetak = document.getElementsByName("pocetak")[0];
var kraj = document.getElementsByName("kraj")[0];
var prethodniB = document.getElementsByClassName("bPrethodni")[0];
var sljedeciB = document.getElementsByClassName("bSljedeci")[0];

//pozovemo jednom na pocetku
Kalendar.ucitajPodatke(pocPeriodicni, pocVanredni);
Kalendar.iscrtajKalendar(kalendar, 10);

//defaultne vrijednosti forme i provjera jesu li svi uneseni
function ocistiFormu() {
    sale.value = "va";
    periodicna.checked = false;
    pocetak.value = "";
    kraj.value = "";
}

//button clicks
prethodniB.addEventListener("click", function() {
    ocistiFormu();
    Kalendar.iscrtajKalendar(kalendar, Mjesec.trenutniMjesec() - 1);
});

sljedeciB.addEventListener("click", function() {
    ocistiFormu();
    Kalendar.iscrtajKalendar(kalendar, Mjesec.trenutniMjesec() + 1);
});

//dodamo onChange listenere za sale,periodicna,pocetak i kraj kako je receno u postavci
sale.addEventListener("change", function() {
    if (pocetak.value.length > 0 && kraj.value.length > 0) {
        Kalendar.obojiZauzeca(
            kalendar,
            Mjesec.trenutniMjesec(),
            sale.value,
            pocetak.value,
            kraj.value
        );
        console.log("obojiZauzeca");
    }
});

/* //checkbox cemo kasnije
periodicna.addEventListener("change", function(){
    if(pocetak.value.length>0 && kraj.value.length>0)
        Kalendar.obojiZauzeca(kalendar,Mjesec.trenutniMjesec,sale.value,pocetak.value,kraj.value);
});
*/

pocetak.addEventListener("change", function() {
    if (pocetak.value.length > 0 && kraj.value.length > 0) {
        Kalendar.obojiZauzeca(
            kalendar,
            Mjesec.trenutniMjesec(),
            sale.value,
            pocetak.value,
            kraj.value
        );
        console.log("obojiZauzeca");
    }
});

kraj.addEventListener("change", function() {
    if (pocetak.value.length > 0 && kraj.value.length > 0) {
        Kalendar.obojiZauzeca(
            kalendar,
            Mjesec.trenutniMjesec(),
            sale.value,
            pocetak.value,
            kraj.value
        );
        console.log("obojiZauzeca");
    }
});
