var sale = document.getElementsByName("sale")[0];
for(i=0; i<=3; i++){
    for(j=1; j<=7; j++){
        sale.innerHTML+= "<option value=\"" + i +"-0"+j+"\">"+ i +"-0"+j+"</option>\n";
    }
}