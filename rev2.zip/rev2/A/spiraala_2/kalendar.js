var pocVanredni = [
    {
        datum: new Date("2019-11-8"),
        pocetak: "08:00",
        kraj: "09:30",
        naziv: "1-01",
        predavac: "Sabko Sabkovic"
    },
    {
        datum: new Date("2019-1-8"),
        pocetak: "08:00",
        kraj: "09:30",
        naziv: "1-01",
        predavac: "Sabko Sabkovic"
    },
    {
        datum: new Date("2019-2-8"),
        pocetak: "08:00",
        kraj: "09:30",
        naziv: "1-01",
        predavac: "Sabko Sabkovic"
    },
    {
        datum: new Date("2019-3-8"),
        pocetak: "08:00",
        kraj: "09:30",
        naziv: "1-01",
        predavac: "Sabko Sabkovic"
    },
    {
        datum: new Date("2019-4 -8"),
        pocetak: "08:00",
        kraj: "09:30",
        naziv: "1-01",
        predavac: "Sabko Sabkovic"
    }
];

var pocPeriodicni = [
    {
        dan: 3,
        semestar: "zimski",
        pocetak: "08:00",
        kraj: "09:30",
        naziv: "2-02",
        predavac: "Scooby Dooby Doo"
    },
    {
        dan: 1,
        semestar: "zimski",
        pocetak: "08:30",
        kraj: "10:00",
        naziv: "VA",
        predavac: "Scooby Dooby Doo"
    },
    {
        dan: 1,
        semestar: "ljetni",
        pocetak: "08:00",
        kraj: "09:30",
        naziv: "2-03",
        predavac: "Scooby Dooby Doo"
    }
];

let Mjesec = (function() {
    var trenutniMjesec = 10;
    var trenutniPoc = 4; //petak
    var dani = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var nazivi = [
        "Januar",
        "Februar",
        "Mart",
        "April",
        "Maj",
        "Juni",
        "Juli",
        "August",
        "Septembar",
        "Oktobar",
        "Novembar",
        "Decembar"
    ];
    var trenutniKraj = (4 + dani[trenutniMjesec] - 1) % 7;

    function sljedeciImpl() {
        if (trenutniMjesec == 11) return;
        trenutniMjesec++; //12
        trenutniPoc = (trenutniKraj + 1) % 7; //5 sub
        trenutniKraj = (trenutniPoc + dani[trenutniMjesec] - 1) % 7; //zadnji dan 1
    }

    function prethodniImpl() {
        if (trenutniMjesec == 0) return;
        trenutniMjesec--;
        trenutniKraj = trenutniPoc - 1;
        if (trenutniKraj == -1) trenutniKraj = 6;
        trenutniPoc -= dani[trenutniMjesec];
        trenutniPoc += (Math.floor(trenutniPoc / -7) + 1) * 7;
        trenutniPoc %= 7;
    }

    function getTrenutniMjesec() {
        return trenutniMjesec;
    }

    function getNazivMjseeca() {
        return nazivi[trenutniMjesec];
    }

    function getPocDan() {
        return trenutniPoc;
    }

    function getBrojDana() {
        return dani[trenutniMjesec];
    }

    function getTrenutniPoc() {
        return trenutniPoc;
    }

    function getTrenutniKraj() {
        return trenutniKraj;
    }

    return {
        prethodni: prethodniImpl,
        sljedeci: sljedeciImpl,
        trenutniMjesec: getTrenutniMjesec,
        nazivTrenutnog: getNazivMjseeca,
        pocDanMjeseca: getPocDan,
        brojDanaMjeseca: getBrojDana,
        trenutniPoc: getTrenutniPoc,
        trenutniKraj: getTrenutniKraj
    };
})();

let Kalendar = (function() {
    var zauzeca = [];

    //Test presjeka 2 vremenska opsega
    function presjekVremena(poc1, kraj1, poc2, kraj2) {
        let ukupMinutePoc1 = parseInt(poc1.substr(0, 2)) * 60 + parseInt(poc1.substr(3, 2));
        let ukupMinuteKraj1 = parseInt(kraj1.substr(0, 2)) * 60 + parseInt(kraj1.substr(3, 2));

        let ukupMinutePoc2 = parseInt(poc2.substr(0, 2)) * 60 + parseInt(poc2.substr(3, 2));
        let ukupMinuteKraj2 = parseInt(kraj2.substr(0, 2)) * 60 + parseInt(kraj2.substr(3, 2));
        //drugi pocinje prije nego sto prvi zavrsi i prvi pocinje prije nego sto drugi zavrsi
        //znaci da ova 2 vremena imaju presjekp
        let drugoSadrzanoUPrvom = ukupMinutePoc2 < ukupMinuteKraj1 && ukupMinutePoc1 < ukupMinuteKraj2;
        return drugoSadrzanoUPrvom; //refaktoring
    }

    function validirajVrijeme(poc1, kraj1) {
        if(poc1.length<5 || kraj1.length<5) return false; //necemo predetaljno u validaciju
        let ukupMinutePoc1 = parseInt(poc1.substr(0, 2)) * 60 + parseInt(poc1.substr(3, 2));
        let ukupMinuteKraj1 = parseInt(kraj1.substr(0, 2)) * 60 + parseInt(kraj1.substr(3, 2));
        if (ukupMinutePoc1 >= ukupMinuteKraj1) return false;
        return true;
    }

    function oslobodiKalendar(kalendarRef){
        let celije = kalendarRef.getElementsByClassName("broj");
        let i=0;
        for(i=0; i<celije.length; i++){
            if(!celije[i].parentElement.parentElement.getElementsByClassName("slobodna").length==1)
                celije[i].parentElement.parentElement.getElementsByClassName("zauzeta")[0].className="slobodna";
        }
    }

    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
        if (mjesec != Mjesec.trenutniMjesec() || !validirajVrijeme(pocetak, kraj) || kalendarRef == null) {
            oslobodiKalendar(kalendarRef); //ako je neispravno, oboji sve u zeleno
            return; //validacija
        }

        let celije = kalendarRef.getElementsByClassName("broj");
        let i = 0,
            j = 0;
        for (i = 0; i < celije.length; i++) {
            for (j = 0; j < zauzeca.length; j++) {
                let el = zauzeca[j];
                let isteSale = el.naziv.toUpperCase() === sala.toUpperCase();
                let zauzetoVrijeme = presjekVremena(pocetak, kraj, el.pocetak, el.kraj);
                if (el.datum.getMonth() == mjesec && isteSale && zauzetoVrijeme && el.datum.getDate() == i + 1) {
                    if (!(celije[i].parentElement.parentElement.getElementsByClassName("zauzeta").length == 1))
                        celije[i].parentElement.parentElement.getElementsByClassName("slobodna")[0].className = "zauzeta";
                    break;
                }
            }
            //ako nismo zauzeli ovaj termin, obojimo ga u zeleno ako je ostao od neke prethodne konfiguracije forme
            if (j == zauzeca.length && !(celije[i].parentElement.parentElement.getElementsByClassName("slobodna").length == 1)) {
                celije[i].parentElement.parentElement.getElementsByClassName("zauzeta")[0].className = "slobodna";
            }
        }
    }

    function dajSvaPeriodicna(periodicna) {
        var rez = [];
        if (periodicna.semestar == "zimski") {
            //oktobar novembar decembar januar
            let prviDatum = new Date("1-1-2019");
            //posebno januar jer nema sad sljedece godine

            //pomjerimo na prvi validan dan i onda ostale
            while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
                prviDatum.setDate(prviDatum.getDate() + 1);
            }

            while (prviDatum.getMonth() == 0) {
                rez.push({
                    datum: new Date(prviDatum),
                    pocetak: periodicna.pocetak,
                    kraj: periodicna.kraj,
                    naziv: periodicna.naziv,
                    predavac: periodicna.predavac
                });
                prviDatum.setDate(prviDatum.getDate() + 7);
            }

            //sad radimo ostale mjesece
            prviDatum = new Date("10-1-2019");
            while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
                prviDatum.setDate(prviDatum.getDate() + 1);
            }
            while (prviDatum.getMonth() >= 9 && prviDatum.getMonth() <= 11) {
                rez.push({
                    datum: new Date(prviDatum),
                    pocetak: periodicna.pocetak,
                    kraj: periodicna.kraj,
                    naziv: periodicna.naziv,
                    predavac: periodicna.predavac
                });
                prviDatum.setDate(prviDatum.getDate() + 7);
            }
        } else if (periodicna.semestar == "ljetni") {
            //feb mart april maj juni
            prviDatum = new Date("2-1-2019");
            while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
                prviDatum.setDate(prviDatum.getDate() + 1);
            }
            while (prviDatum.getMonth() >= 1 && prviDatum.getMonth() <= 5) {
                rez.push({
                    datum: new Date(prviDatum),
                    pocetak: periodicna.pocetak,
                    kraj: periodicna.kraj,
                    naziv: periodicna.naziv,
                    predavac: periodicna.predavac
                });
                prviDatum.setDate(prviDatum.getDate() + 7);
            }
        }
        return rez;
    }

    function ucitajPodatkeImpl(periodicna, vanredna) {
        //na sva vanredna dodaj jos periodicna kada ih pretvorimo u konkretne vanredne termine pomocu metode dajSvaPeriodicna
        let rez = [];
        rez = rez.concat(vanredna);
        periodicna.forEach(el => {
            rez = rez.concat(dajSvaPeriodicna(el));
        });
        zauzeca = rez;
    }

    function iscrtajDan(klasa1, klasa2, tekst) {
        return (
            '<table>\n<tr>\n<td class="' +
            klasa1 +
            '">' +
            tekst +
            '</td>\n</tr>\n<tr>\n<td class="' +
            klasa2 +
            '"></td>\n</tr>\n</table>'
        );
    }
    function iscrtajKalendarImpl(kalendarRef, mjesec) {
        if (mjesec < 0 || mjesec > 11) return;
        //azuriramo trenutniMjesec na zadanu vrijednost
        while (mjesec > Mjesec.trenutniMjesec()) {
            Mjesec.sljedeci();
        }
        while (mjesec < Mjesec.trenutniMjesec()) {
            Mjesec.prethodni();
        }
        document.getElementById("nazivMjeseca").innerHTML = Mjesec.nazivTrenutnog();
        //iscrtamo prvu sedmicu pazeci na prazne
        let prvaSed = document.getElementsByClassName("prvaSedmica")[0];
        prvaSed.innerHTML = "";
        let prazne = Mjesec.pocDanMjeseca() - 1;
        while (prazne >= 0) {
            prvaSed.innerHTML += iscrtajDan("prazna", "prazna", "");
            prazne--;
        }
        let punePrve = 6 - Mjesec.pocDanMjeseca();
        let gornja = Mjesec.brojDanaMjeseca();
        let brojac = 1;

        while (punePrve >= 0) {
            prvaSed.innerHTML += iscrtajDan("broj", "slobodna", brojac++);
            punePrve--;
        }
        let ostatakMj = document.getElementsByClassName("ostatakMj")[0];
        ostatakMj.innerHTML = "";
        while (brojac <= gornja) {
            ostatakMj.innerHTML += iscrtajDan("broj", "slobodna", brojac++);
        }
    }

    return {
        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl,
        iscrtajKalendar: iscrtajKalendarImpl,
        dajSvaPeriodicna: dajSvaPeriodicna
    };
})();
