let assert = chai.assert;
describe('Kalendar', function() {
  describe('iscrtajKalendar()', function() {
    //mjesec sa 30 dana-novembar
    it('Novembar - Trebalo bi iscrtati 30 dana', function () {
    	let kalendar = document.getElementById("containerDiv");
      removeAllChildNodes();
    	Kalendar.iscrtajKalendar(kalendar, 10);
    	let iscrtaniDani = document.getElementsByClassName("outterDiv");
    	assert.equal(iscrtaniDani.length, 30, '30 dana iscrtano');
    });

    //mjesec sa 31 dan-decembar
    it('Decembar - Trebalo bi iscrtati 31 dan', function () {
      let kalendar = document.getElementById("containerDiv");
      removeAllChildNodes();
      Kalendar.iscrtajKalendar(kalendar, 11);
      let iscrtaniDani = document.getElementsByClassName("outterDiv");
      assert.equal(iscrtaniDani.length, 31, '31 dan iscrtan');
    });

    //trenutni mjesec (novembar)
    it('Trenutni - Trebao bi prvi dan biti u petak', function () {
      let kalendar = document.getElementById("containerDiv");
      removeAllChildNodes();
      Kalendar.iscrtajKalendar(kalendar, 10);
      let prviDan = document.getElementsByClassName("outterDiv").item(0);
      assert.equal(document.querySelector("#containerDiv :nth-child(12)"), prviDan, '1. dan je u petak'); //prvih 7 djece su nazivi dana, a onda idu prazni divovi do prvog dana u mjesecu
    });

    //trenutni mjesec (novembar)
    it('Trenutni - Trebao bi 30.dan biti u subotu', function () {
      let kalendar = document.getElementById("containerDiv");
      removeAllChildNodes();
      Kalendar.iscrtajKalendar(kalendar, 10);
      let tridesetiDan = document.getElementsByClassName("outterDiv").item(29);
      assert.equal(document.querySelector("#containerDiv :nth-child(41)"), tridesetiDan, '30. dan je u subotu');
    });

    //januar
    it('Januar - Trebali bi brojevi dana ići od 1-31 počevši od utorka', function () {
      let kalendar = document.getElementById("containerDiv");
      removeAllChildNodes();
      Kalendar.iscrtajKalendar(kalendar, 0);
      let prviDan = document.getElementsByClassName("outterDiv").item(0);
      let zadnjiDan = document.getElementsByClassName("outterDiv").item(30);
      assert.equal(document.querySelector("#containerDiv :nth-child(9)"), prviDan, 'Dani počinju od utorka');
      assert.equal(prviDan.innerHTML, '1<div class="bottomDiv"></div>', 'Dani počinju sa 1');
      assert.equal(zadnjiDan.innerHTML, '31<div class="bottomDiv"></div>', 'Dani završavaju sa 31');
    });

    //februar
    it('Februar - Trebao bi počinjati u petak a završavati u četvrtak', function () {
      let kalendar = document.getElementById("containerDiv");
      removeAllChildNodes();
      Kalendar.iscrtajKalendar(kalendar, 1);
      let prviDan = document.getElementsByClassName("outterDiv").item(0);
      let zadnjiDan = document.getElementsByClassName("outterDiv").item(27);
      assert.equal(document.querySelector("#containerDiv :nth-child(12)"), prviDan, '1. dan je u petak');
      assert.equal(document.querySelector("#containerDiv :nth-child(39)"), zadnjiDan, '28. dan je u petak');
    });

    //august
    it('August - Trebao bi iscrtati 31. dan', function () {
      let kalendar = document.getElementById("containerDiv");
      removeAllChildNodes();
      Kalendar.iscrtajKalendar(kalendar, 7);
      let dani = document.getElementsByClassName("outterDiv");
      assert.equal(dani.length, 31, '31 dan iscrtan');
    });


  });

  describe ('obojiZauzeca() i ucitajPodatke()', function () {
      //podaci nisu ucitani
      it('Podaci nisu učitani - ništa se ne boji', function () {
        let kalendar = document.getElementById("containerDiv");
        removeAllChildNodes();
        Kalendar.iscrtajKalendar(kalendar, 10);
        Kalendar.ucitajPodatke(null, null);
        Kalendar.obojiZauzeca(kalendar, 2, "0-02", "13:00", "14:00");
        let zauzetiDani = document.getElementsByClassName("zauzeta");
        assert.equal(zauzetiDani.length, 0, '0 dana zauzeto');
      });

      //dva zauzeća na isti dan
      it ('Dupla zauzeća - oboji', function () {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();
          Kalendar.iscrtajKalendar(kalendar, 10);

          var periodicno1 = {
            dan : "0",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var vanredno1 = {
            datum : "11.11.2019",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicna = [periodicno1];
          var vanredna = [vanredno1];
          Kalendar.ucitajPodatke(periodicna, vanredna);
          Kalendar.obojiZauzeca(kalendar, 10, "0-01", "14:30", "16:00");
          let zauzetiDani = document.getElementsByClassName("zauzeta");
          assert.equal(document.querySelector("#containerDiv :nth-child(15)").classList.contains("zauzeta"), true, '1. ponedjeljak crven');
          assert.equal(document.querySelector("#containerDiv :nth-child(22)").classList.contains("zauzeta"), true, '2. ponedjeljak crven');
          assert.equal(document.querySelector("#containerDiv :nth-child(29)").classList.contains("zauzeta"), true, '3. ponedjeljak crven');
          assert.equal(document.querySelector("#containerDiv :nth-child(36)").classList.contains("zauzeta"), true, '4. ponedjeljak crven');

      });

      //postoji periodicno zauzeće za drugi semestar
      it ('Zauzece u ljetnom semestru - ne boji', function () {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();
          Kalendar.iscrtajKalendar(kalendar, 10);

          var periodicno1 = {
            dan : "0",
            semestar : "ljetni",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicna = [periodicno1];
          var vanredna = [];
          Kalendar.ucitajPodatke(periodicna, vanredna);
          Kalendar.obojiZauzeca(kalendar, 10, "0-01", "14:30", "16:00");
          let zauzetiDani = document.getElementsByClassName("zauzeta");
          assert.equal(zauzetiDani.length, 0, 'Nista nije zauzeto u novembru');

      });

      //postoji zauzece u januaru a mi smo u novembru
      it ('Zauzece u drugom mjesecu - ne boji', function () {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();
          Kalendar.iscrtajKalendar(kalendar, 10);

          var vanredno1 = {
            datum : "11.01.2019",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var vanredna = [vanredno1];
          var periodicna = [];
          Kalendar.ucitajPodatke(periodicna, vanredna);
          Kalendar.obojiZauzeca(kalendar, 10, "0-01", "14:30", "16:00");
          let zauzetiDani = document.getElementsByClassName("zauzeta");
          assert.equal(zauzetiDani.length, 0, 'Nista nije zauzeto u novembru');

      });

      //svi termini zauzeti
      it ('Svi termini zauzeti - boji sve', function () {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();
          Kalendar.iscrtajKalendar(kalendar, 10);

          var periodicno1 = {
            dan : "0",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicno2 = {
            dan : "1",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicno3 = {
            dan : "2",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicno4 = {
            dan : "3",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicno5 = {
            dan : "4",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicno6 = {
            dan : "5",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periodicno7 = {
            dan : "6",
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }

          var periodicna = [periodicno1, periodicno2, periodicno3, periodicno4, periodicno5, periodicno6, periodicno7];
          var vanredna = [];
          Kalendar.ucitajPodatke(periodicna, vanredna);
          Kalendar.obojiZauzeca(kalendar, 10, "0-01", "14:30", "16:00");
          let slobodniDani = document.getElementsByClassName("slobodna");
          assert.equal(slobodniDani.length, 0, 'Sve je zauzeto u novembru');

      });

      //dva puta uzastopno pozivanja obojiZauzeca
      it ('Dva puta uzastopno pozivanja obojiZauzeca - ostaje isto', function() {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();
          Kalendar.iscrtajKalendar(kalendar, 9);

          var vanredno1 = {
            datum : "02.10.2019",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var vanredna = [vanredno1];
          var periodicna = [];
          Kalendar.ucitajPodatke(periodicna, vanredna);
          Kalendar.obojiZauzeca(kalendar, 9, "0-01", "14:30", "16:00");
          let zauzetiDani1 = document.getElementsByClassName("zauzeta");
          Kalendar.obojiZauzeca(kalendar, 9, "0-01", "14:30", "16:00");
          let zauzetiDani2 = document.getElementsByClassName("zauzeta");
          assert.equal(zauzetiDani1.length, zauzetiDani2.length, 'Isti broj zauzetih dana');
      });

      //ucitavanje i bojenje novih podataka preko starih
      it ('Učitavanje i bojenje novih podataka preko starih - ostaju samo novi', function () {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();
          Kalendar.iscrtajKalendar(kalendar, 9);

          var vanredno1 = {
            datum : "02.10.2019", // prva srijeda u oktobru
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var vanredna = [vanredno1];
          Kalendar.ucitajPodatke([], vanredna);
          Kalendar.obojiZauzeca(kalendar, 9, "0-01", "14:30", "16:00");
          let obojeniDan = document.getElementsByClassName("zauzeta").item(0); // samo se srijeda trebala obojiti

          var periodicno1 = { 
            dan : "5", // boji svaku subotu u semestru (i oktobru)
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "0-01",
            predavac : "Vensada Okanović"
          }
          var periocna = [periodicno1];
          Kalendar.ucitajPodatke(periocna, []);
          Kalendar.obojiZauzeca(kalendar, 9, "0-01", "14:30", "16:00");
          let obojeniDani = document.getElementsByClassName("zauzeta");
          for (var i = 0; i < obojeniDani.length; i++) {
            assert.notEqual(obojeniDani.item(i), obojeniDan, 'Prvobitni dan nije više obojen');
          }

      });

      //pozivanje obojiZauzeca sa ucitanim neispravnim podacima 
      it ('Učitaju se zauzeća s neispravnim podacima - ne oboji se ništa i ne krahira', function() {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();
          Kalendar.iscrtajKalendar(kalendar, 4);
          var periodicno1 = { 
            dan : "10", 
            semestar : "semestar",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "AMFITEATAR",
            predavac : "Vensada Okanović"
          }
          var periodicna = [periodicno1];
          Kalendar.ucitajPodatke(periodicna, []);
          Kalendar.obojiZauzeca(kalendar, 4, "0-01", "14:30", "16:00");
          let zauzetiDani = document.getElementsByClassName("zauzeta");
          assert.equal(zauzetiDani.length, 0, 'Ništa nije zauzeto');
      });

      //provjera da li semestri obuhvataju mjesece juli, august i septembar
      it ('Semestri ne obuhvataju juli, august i septembar', function() {
          let kalendar = document.getElementById("containerDiv");
          removeAllChildNodes();          
          var periodicno1 = { 
            dan : "1", 
            semestar : "zimski",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "1-02",
            predavac : "Vensada Okanović"
          }
          var periodicno2 = { 
            dan : "0", 
            semestar : "ljetni",
            pocetak : "14:30",
            kraj : "16:00",
            naziv : "1-02",
            predavac : "Vensada Okanović"
          }
          var periodicna = [periodicno1, periodicno2];
          Kalendar.ucitajPodatke(periodicna, []);

          Kalendar.iscrtajKalendar(kalendar, 6);          
          Kalendar.obojiZauzeca(kalendar, 6, "1-01", "14:30", "16:00");
          let zauzetiDani1 = document.getElementsByClassName("zauzeta");
          assert.equal(zauzetiDani1.length, 0, 'Ništa nije zauzeto u julu');

          Kalendar.iscrtajKalendar(kalendar, 7);          
          Kalendar.obojiZauzeca(kalendar, 7, "1-01", "14:30", "16:00");
          let zauzetiDani2 = document.getElementsByClassName("zauzeta");
          assert.equal(zauzetiDani2.length, 0, 'Ništa nije zauzeto u augustu');

          Kalendar.iscrtajKalendar(kalendar, 8);          
          Kalendar.obojiZauzeca(kalendar, 8, "1-01", "14:30", "16:00");
          let zauzetiDani3 = document.getElementsByClassName("zauzeta");
          assert.equal(zauzetiDani3.length, 0, 'Ništa nije zauzeto u septembru');


      });


  });

});
