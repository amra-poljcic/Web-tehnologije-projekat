var recall= null; //kontrola ajax poziva (30 s)
