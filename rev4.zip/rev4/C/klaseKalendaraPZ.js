class periodicnoZauzece{
    dan;
    semestar;
    pocetak;
    kraj;
    naziv;
    predavac;
    constructor(dan, semestar, pocetak, kraj, naziv, predavac){
        this.dan = dan;
        this.semestar = semestar;
        this.pocetak = pocetak;
        this.kraj = kraj;
        this.naziv = naziv;
        this.predavac = predavac;
    }
    }
module.exports = periodicnoZauzece;