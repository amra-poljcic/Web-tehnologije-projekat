const db = require("./db.js");
db.sequelize.sync({force:true}).then(function(){
    upisivanjePodataka().then(function(){
        console.log("Uspjesno kreiranje tabela i upisivanje podataka!");
        //process.exit();
    });
});

function upisivanjePodataka(){
    var listaOsoblja = [];
    var listaSala = [];
    var listaTermina = [];
    var listaRezervacija = [];
    return new Promise(function(resolve, reject){
        listaOsoblja.push(db.osoblje.create({ime:"Neko", prezime:"Nekić", uloga:"profesor"}));
        listaOsoblja.push(db.osoblje.create({ime:"Drugi", prezime:"Neko", uloga:"asistent"}));
        listaOsoblja.push(db.osoblje.create({ime:"Test", prezime:"Test", uloga:"asistent"}));
        Promise.all(listaOsoblja).then(function(osoblje){
            var osoba1 = osoblje.filter(function(d){return d.id == "1"})[0];
            var osoba2 = osoblje.filter(function(d){return d.id == "2"})[0];
            listaSala.push(
                db.sala.create({naziv:"1-11"}).then(function(k){
                    k.setOsoblje(osoba1);
                    return new Promise(function(resolve, reject){resolve(k);});
                })
            );
            listaSala.push(
                db.sala.create({naziv:"1-15"}).then(function(k){
                    k.setOsoblje(osoba2);
                    return new Promise(function(resolve, reject){resolve(k);});
                })
            );
            Promise.all(listaSala).then(function(sale){
                listaTermina.push(db.termin.create({redovni:false, dan:null, datum:"01.01.2020", semestar:null, pocetak:"12:00", kraj:"13:00"}));
                listaTermina.push(db.termin.create({redovni:true, dan:0, datum:null, semestar:"zimski", pocetak:"13:00", kraj:"14:00"}));
                Promise.all(listaTermina).then(function(termini){
                    var osoba3 = osoblje.filter(function(d){return d.id == "1"})[0];
                    var sala1 = sale.filter(function(d){return d.id == "1"})[0];
                    var termin1 = termini.filter(function(d){return d.id == "1"})[0];

                    listaRezervacija.push(
                        db.rezervacije.create().then(function(k){
                                return k.setTermin(termin1).then(function(){
                                    return k.setSala(sala1).then(function(){
                                        return k.setOsoblje(osoba3).then(function(){
                                            return new Promise(function(resolve, reject){resolve(k);});
                                        });
                                    });
                                });
                            })
                         );
                    /*listaRezervacija.push(
                        db.rezervacije.create().then(function(k){
                            k.setTermin(termin1);
                            k.setSala(sala1);
                            k.setOsoblje(osoba3);
                            return new Promise(function(resolve, reject){resolve(k);});
                        })
                    );*/
                    
                    var osoba4 = osoblje.filter(function(d){return d.id == "3"})[0];
                    var sala2 = sale.filter(function(d){return d.id == "1"})[0];
                    var termin2 = termini.filter(function(d){return d.id == "2"})[0];
                    
                    listaRezervacija.push(
                        db.rezervacije.create().then(function(k){
                                return k.setTermin(termin2).then(function(){
                                    return k.setSala(sala2).then(function(){
                                        return k.setOsoblje(osoba4).then(function(){
                                            return new Promise(function(resolve, reject){resolve(k);});
                                        });
                                    });
                                });
                            })
                         );
                    Promise.all(listaRezervacija).then(function(k){resolve(k);}).catch(function(err){console.log("Rezervacija greska" + err);});
                }).catch(function(err){console.log("Termini greska" + err);});
            }).catch(function(err){console.log("Sale greska" + err);});
        }).catch(function(err){console.log("Osoblje greska" + err);});
    });
    
}