const express = require('express');
const bodyParser = require("body-parser");
const fs = require('fs');
const app = express();
const vanrednoZauzece = require("./klaseKalendaraVZ.js");
const periodicnoZauzece = require("./klaseKalendaraPZ.js");
const kreiranje = require("./pravljenjeTabela.js");
const db = require("./db.js");
module.exports = app;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

app.get("/", function(req, res){
    res.sendFile(__dirname + "/pocetna.html");
});

app.get("/osoblje", function(req, res){
    db.osoblje.findAll().then(function(osoblje){
        res.json(osoblje); 
    })  
});
app.get("/sale", function(req, res){
    db.sala.findAll().then(function(sale){
        res.json(sale); 
    })  
});

app.get("/osobljeUSalama", function(req, res){
    datum = new Date();
    var listaOsoba = [];
    var listaSala = [];
    db.rezervacije.findAll({ include: [{
        model: db.sala,
        required: true
    },
    {
        model: db.termin,
        required: true,
    },
    {
        model: db.osoblje,
        required: true
    }]
    }).then(function(result){
        result.forEach(element => {
        if(compareTime(element.Termin.pocetak, (datum.getHours()+":"+datum.getMinutes()), element.Termin.kraj, (datum.getHours()+":"+datum.getMinutes()))){
            //console.log("ovdje");
            if(element.Termin.redovni == false){
                var dateParts = element.Termin.datum.split(".");
                var date = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 
                if(datum.getMonth() == date.getMonth() && datum.getDate() == date.getDate() && datum.getFullYear() == date.getFullYear()){
                    listaOsoba.push(element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga);
                    listaSala.push(element.Sala.naziv);
                }
            }
            else if(element.Termin.redovni == true){
                var trenutniSemestar;
                var trenutniMjesec = datum.getMonth();
                if(trenutniMjesec > 0 && trenutniMjesec < 5) trenutniSemestar = "ljetni";
                else trenutniSemestar = "zimski";
                day = datum.getDay();
                day = (day===0) ? 7 : day;
                day--;
                if(day == element.Termin.dan && element.Termin.semestar == trenutniSemestar){
                    listaOsoba.push(element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga);
                    listaSala.push(element.Sala.naziv);
                }
            }
        }
        });
        db.osoblje.findAll().then(function(svoOsoblje){
            svoOsoblje.forEach(element => {
                var str = element.ime + " " + element.prezime + " " + element.uloga;
                if(listaOsoba.indexOf(str) == -1){
                    listaOsoba.push(str);
                    listaSala.push("U kancelariji");
                }
            });
            res.json({liste:{listaOsoba, listaSala}});
        })

    })
})


app.post("/rezervacija.html", function(req, res){
    db.rezervacije.findAll({ include: [{
        model: db.sala,
        required: true
    },
    {
        model: db.termin,
        required: true
    },
    {
        model: db.osoblje,
        required: true
    }]
    }).then(function(rezultat){
        var vanredna = [];
        var periodicna = [];
        //console.log(rezultat[0]);
        rezultat.forEach(element => {
            if(element.Termin.redovni == false){
                let vanZauzece = new vanrednoZauzece(element.Termin.datum, element.Termin.pocetak, element.Termin.kraj, element.Sala.naziv, element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga);
                vanredna.push(vanZauzece);
            }
            else if(element.Termin.redovni == true){
                let zauzece1 = new periodicnoZauzece(element.Termin.dan, element.Termin.semestar, element.Termin.pocetak, element.Termin.kraj, element.Sala.naziv, element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga);
                periodicna.push(zauzece1);
            }

        });
        res.json({zauzeca:{periodicna, vanredna}});
    })
});



app.get("/pocetna.html/slikeTest", function(req, res){
    res.sendFile(__dirname + "/Photos/Slika1.jpg");
});
app.post("/pocetna.html/slike", function(req, res){
    var ucitaneSlike = [];
    var ucitaneSlike = req.body;
    var nazivi = [];
    fs.readdir("Photos", function(err, filenames) {
        if (err) {
          onError(err);
          return;
        }
        filenames.forEach(element => {
            if(!ucitaneSlike.includes(element)){
                nazivi.push(element.toString());
            }
        });
        var izlaz = [];
      if(nazivi.length>=3)
      for(i=0; i<3; i++){
        izlaz.push(nazivi[i]);
      }
      else izlaz = nazivi;
      res.json(izlaz);
      });
});

app.post("/rezervacija.html/periodicno", function(req, res){
    var obj = req.body;
    var izlaz = false;
    db.rezervacije.findAll({ include: [{
        model: db.sala,
        required: true,
        //where: {naziv : obj.naziv}
    },
    {
        model: db.termin,
        required: true,
        where: {semestar: obj.semestar, dan: obj.dan}
    },{
        model: db.osoblje,
        required: true
    }]
    }).then(function(result){
    
        result.forEach(element => {
            if(compareTime(element.Termin.pocetak, obj.pocetak, element.Termin.kraj, obj.kraj) && element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga == obj.predavac){
                res.status(201).end("Predavac: " + obj.predavac + ", vec ima rezervisanu drugu salu u istom terminu!");
                izlaz = true;
                return;
                }
        });


    db.rezervacije.findAll({ include: [{
        model: db.sala,
        required: true,
        where: {naziv : obj.naziv}
    },
    {
        model: db.termin,
        required: true,
        where: {semestar: obj.semestar, dan: obj.dan}
    },{
        model: db.osoblje,
        required: true
    }]
    }).then(function(rezultat){
        rezultat.forEach(element => {
            if(compareTime(element.Termin.pocetak, obj.pocetak, element.Termin.kraj, obj.kraj)){ 
                res.status(201).end("Nije moguce rezervisati salu " + obj.naziv + " jer ju je rezervisao: " + element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga);
                izlaz = true;
            }
        });
        if(!izlaz){
            db.termin.create({ redovni : true, dan : obj.dan, datum : null, semestar : obj.semestar, pocetak : obj.pocetak, kraj : obj.kraj}).then(function(termin2){
                db.sala.findAll({where : {
                    naziv : obj.naziv
                }}).then(function(sala2){
                    var res1 = obj.predavac.split(" ");
                    db.osoblje.findAll({where : {
                        ime : res1[0],
                        prezime : res1[1],
                        uloga : res1[2]
                    }}).then(function(osoba2){
                        db.rezervacije.create({termin : termin2.id, sala : sala2[0].id, osoba : osoba2[0].id}).then(function(k){
                            res.json(k);
                        });
                    })
                })
            })
        }
    })
    })
})


app.post("/rezervacija.html/vanredno", function(req, res){
    var obj = req.body;
    var date1 = ispraviDatum(obj.datum);
    var izlaz = false;
    db.rezervacije.findAll({ include: [{
        model: db.sala,
        required: true,
    }, 
    {
        model: db.termin,
        required: true,
        where : {datum : date1}
    },{
        model: db.osoblje,
        required: true
    }]
    }).then(function(result){

        result.forEach(element => {
            if(compareTime(element.Termin.pocetak, obj.pocetak, element.Termin.kraj, obj.kraj) && element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga == obj.predavac){
            res.status(201).end("Predavac: " + obj.predavac + ", vec ima rezervisanu drugu salu u istom terminu!");
            izlaz = true;
            return;
            }
                
        });
    db.rezervacije.findAll({ include: [{
        model: db.sala,
        required: true,
        where : {naziv : obj.naziv}
    }, 
    {
        model: db.termin,
        required: true,
        where : {datum : date1}
    },{
        model: db.osoblje,
        required: true
    }]
    }).then(function(rezultat){
        rezultat.forEach(element => {
            if(compareTime(element.Termin.pocetak, obj.pocetak, element.Termin.kraj, obj.kraj)){
                res.status(201).end("Nije moguce rezervisati salu " + obj.naziv + " za navedeni datum " + obj.datum + " i termin od " + obj.pocetak + " do " + obj.kraj + " jer ju je rezervisao: " + element.Osoblje.ime + " " + element.Osoblje.prezime + " " + element.Osoblje.uloga);
                izlaz = true;
            }
        });
        if(!izlaz){
            db.termin.create({ redovni : false, dan : null, datum : date1, semestar : null, pocetak : obj.pocetak, kraj : obj.kraj}).then(function(termin2){
                db.sala.findAll({where : {
                    naziv : obj.naziv
                }}).then(function(sala2){
                    var res1 = obj.predavac.split(" ");
                    db.osoblje.findAll({where : {
                        ime : res1[0],
                        prezime : res1[1],
                        uloga : res1[2]
                    }}).then(function(osoba2){
                        db.rezervacije.create({termin : termin2.id, sala : sala2[0].id, osoba : osoba2[0].id}).then(function(k){
                            res.json(k);
                        });
                    })
                })
            })
        }

    })
    })
})


app.listen(8080);

function daLiSuIsti(element, obj){
    var objDatum = compareDate(obj.datum);
    day = objDatum.getDay();
    day = (day===0) ? 7 : day;
    day--;
    if(day == element.dan && element.naziv == obj.naziv && compareTime(element.pocetak, obj.pocetak, element.kraj, obj.kraj)) return true;
    else return false;
}

function compareTime(pocetak1, pocetak2, kraj1, kraj2){
    //trazeno ponasanje ako je pocetak1<pocetak2 && kraj1>kraj2 || pocetak1<pocetak2 && kraj1<kraj2 || pocetak1>pocetak2 && kraj1<kraj2 
    var satPocetak1 = parseInt(pocetak1[0]+pocetak1[1]+pocetak1[3]+pocetak1[4]);

    var satPocetak2 = parseInt(pocetak2[0]+pocetak2[1]+pocetak2[3]+pocetak2[4]);

    var satKraj1 = parseInt(kraj1[0]+kraj1[1]+kraj1[3]+kraj1[4]);

    var satKraj2 = parseInt(kraj2[0]+kraj2[1]+kraj2[3]+kraj2[4]);


    if(satPocetak2>satPocetak1 && satKraj2<satKraj1) return true;
    else if(satPocetak2<=satPocetak1 && satKraj2>=satKraj1) return true;
    else if(satPocetak2>=satPocetak1 && satPocetak2<=satKraj1) return true;
    else if(satKraj2>=satPocetak1 && satKraj2<=satKraj1) return true;
    else if(satPocetak1 == satPocetak2 && satKraj1 == satKraj2) return true;
    else return false;
}
function compareDate(str1){
    if(str1.charAt(1) == '.'){
        var pom = '0' + str1;
        str1 = pom;
    }
    if(str1.charAt(4) == '.'){
        var st = str1.substring(0, 3);
        var st2 = str1.substring(3, ); 
        var pom = st + "0";
        str1 = pom + st2;
    }
    var dt1   = parseInt(str1.substring(0,2));
    var mon1  = parseInt(str1.substring(3,5));
    var yr1   = parseInt(str1.substring(6,10));
    var date1 = new Date(yr1, mon1-1, dt1);
    return date1;
}
function ispraviDatum(str1){
    if(str1.charAt(1) == '.'){
        var pom = '0' + str1;
        str1 = pom;
    }
    if(str1.charAt(4) == '.'){
        var st = str1.substring(0, 3);
        var st2 = str1.substring(3, ); 
        var pom = st + "0";
        str1 = pom + st2;
    }
    return str1;
}