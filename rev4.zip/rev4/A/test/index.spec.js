const supertest = require("supertest");
const chai = require("chai");
const app = require("../index");
const db = require("../public/db");

const trenutniDatum = new Date(Date.now());

before(function(done){
    setTimeout(function(){
        //ceka kreiranje svih podataka, u suprotnom pada neke testove jer ne nađe tabele
        done();
    }, 1000);
});

describe("GET /osoblje", function(){
    it("treba zavrsiti sa statusom 200 (OK) - Dohvaceni podaci", function(done){
        supertest(app)
        .get("/osoblje")
        .expect(200)
        .end(function(err, res){
            if(err) done(err);
            done();
        });
    });
    it("rezultat treba dohvatiti listu osoba", function(done){
        supertest(app)
          .get("/osoblje")
          .end(function(err, res){
            if (err) done(err);
            chai.expect(res.status).to.equal(200);
            chai.expect(res.body).to.be.an("array");
            done();
          });
    });
    it("rezultat treba da sadrzi osobu Test Test asistent", function(done){
        supertest(app)
          .get("/osoblje")
          .end(function(err, res){
            if (err) done(err);
            chai.expect(res.status).to.equal(200);
            chai.expect(res.body).to.deep.include({ime: "Test", prezime: "Test", uloga: "asistent"});
            done();
          });
    });
    it("rezultat treba da sadrzi osobu Neko Nekić profesor", function(done){
        supertest(app)
          .get("/osoblje")
          .end(function(err, res){
            if (err) done(err);
            chai.expect(res.status).to.equal(200);
            chai.expect(res.body).to.deep.include({ime: "Neko", prezime: "Nekić", uloga: "profesor"});
            done();
          });
    });
});

describe("GET /sveRezervacije", function(){
    it("treba zavrsiti sa statusom 200 (OK) - Dohvaceni podaci", function(done){
        supertest(app)
        .get("/sveRezervacije")
        .expect(200)
        .end(function(err, res){
            if(err) done(err);
            done();
        });
    });
    it("rezultat treba imati listu periodicnih i vanrednih zauzeca", function(done){
        supertest(app)
          .get("/sveRezervacije")
          .end(function(err, res){
            if (err) done(err);
            chai.expect(res.status).to.equal(200);
            chai.expect(res.body).to.have.all.keys('periodicna', 'vanredna');
            done();
          });
    });
});

describe("POST /rezervisi", function(){
    let obj = {};
    obj.redovno = true;
    obj.naziv = "0-01";
    obj.dan = dajDan(trenutniDatum);
    obj.semestar = "zimski";
    obj.pocetak = "00:00";
    obj.kraj = "23:59";
    obj.predavac = "Vensada Okanović";
    it("treba zavrsiti sa statusom 200 (OK) - Uspješno rezervisan termin", function(done){
        supertest(app)
        .post("/rezervisi")
        .send(obj)
        .expect(200)
        .end(function(err, res){
            if(err) done(err);
            done();
        });
    });
    it("treba zavrsiti sa statusom 400 - Vec zauzet termin", function(done){
        supertest(app)
        .post("/rezervisi")
        .send(obj)
        .expect(400)
        .end(function(err, res){
            if(err) done(err);
            done();
        });
    });
});

describe("GET /sveRezervacije nakon kreiranja nove rezervacije", function(){
    it("rezultat treba imati novu rezervaciju kreiranu u POST", function(done){
        let obj = {};
        //obj.redovno = true;
        obj.naziv = "0-01";
        obj.dan = dajDan(trenutniDatum);
        obj.semestar = "zimski";
        obj.pocetak = "00:00";
        obj.kraj = "23:59";
        obj.predavac = "Vensada Okanović";
        supertest(app)
          .get("/sveRezervacije")
          .end(function(err, res){
            if (err) done(err);
            chai.expect(res.status).to.equal(200);
            chai.expect(res.body.periodicna).to.deep.include(obj);
            done();
          });
    });
});

describe("GET /lokacijaOsoblja", function(){
    it("rezultat treba imati osobu koja nije u kancelariji - kreirana u POST za trenutni datum cijeli dan", function(done){
        let obj = {};
        obj.osoba = "Vensada Okanović";
        obj.sala = "0-01";
        supertest(app)
          .get("/lokacijaOsoblja")
          .end(function(err, res){
            if (err) done(err);
            chai.expect(res.status).to.equal(200);
            chai.expect(res.body).to.deep.include(obj);
            done();
          });
    });
    it("rezultat treba imati osobu koja je u kancelariji jer nije trenutno zauzeca", function(done){
        let obj = {};
        obj.osoba = "Neko Nekić";
        obj.sala = "Kancelarija";
        supertest(app)
          .get("/lokacijaOsoblja")
          .end(function(err, res){
            if (err) done(err);
            chai.expect(res.status).to.equal(200);
            chai.expect(res.body).to.deep.include(obj);
            done();
          });
    });
});

function dajDan(datum){
    let danSedmice;
    (datum.getDay() == 0) ? danSedmice = 6: danSedmice = datum.getDay()-1;
    return danSedmice;
}