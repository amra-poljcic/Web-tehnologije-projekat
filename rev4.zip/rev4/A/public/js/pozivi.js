let Pozivi = (function(){
    let ajax = new XMLHttpRequest();
    let slike = [];
    let periodicnaZauzeca = [];
    let vanrednaZauzeca = [];
    function ucitajZauzecasaServeraImpl(fnCallback){

        //preuzimanje zauzeca sa servera - Spirala 4
        $.ajax({
            url : "/sveRezervacije",
            method: "GET",
            //contentType : "application/json",
            dataType: "json",
            //data : JSON.stringify(obj),
            success : function(data, status){
                
                periodicnaZauzeca = data.periodicna;
                vanrednaZauzeca = data.vanredna;
                let kalRef = document.getElementById("kalendar");
                let sala = document.getElementById("sala").value;
                let pocetak = document.getElementById("pocetak").value;
                let kraj = document.getElementById("kraj").value;
                fnCallback(periodicnaZauzeca, vanrednaZauzeca);
                osvjezi(kalRef, sala, pocetak, kraj);
                
            },
            error : function(response){
                console.log("Sve rezervacije greška: "+response);
            }
        });
    }
    function rezervisiTerminImpl(dan, mjesec, redovno, pocetak, kraj, naziv, predavac){
        let datum = new Date(2019, mjesec, dan);
        let danSedmice;
        let obj = new Object();
        //kreiranje objekta novog zauzeca, objekat se prosljeduje post metodi umjesto rucnog ubacivanja kao url
        (datum.getDay() == 0) ? danSedmice = 6: danSedmice = datum.getDay()-1;
        if(redovno){
            obj.dan = danSedmice;
            (ljetniSemestar.includes(mjesec)? obj.semestar = "ljetni" : obj.semestar = "zimski");
            obj.redovno = true;
        }
        else{
            mjesec = mjesec+1;
            if(dan<10) dan = "0"+dan;
            if(mjesec<10) mjesec = "0"+mjesec;
            obj.datum = dan+"."+mjesec+".2019";
            mjesec = parseInt(mjesec)-1;
            obj.redovno = false;
        }
        obj.pocetak = pocetak;
        obj.kraj = kraj;
        obj.naziv = naziv;
        obj.predavac = predavac;
        if(redovno) periodicnaZauzeca.push(obj);
        else vanrednaZauzeca.push(obj);

        //nova post metoda

        //post novog zauzeca
        $.ajax({
            url : "/rezervisi",
            method: "POST",
            //contentType : "application/json",
            dataType: "text",
            contentType: "application/json",
            data : JSON.stringify(obj),
            success : function(response){
                
                Pozivi.ucitajZauzecasaServera(Kalendar.ucitajPodatke);
                
            },
            error : function(response){
                alert("Nije moguće rezervisati salu "+naziv+" za navedeni datum "+dan+"/"+(mjesec+1)+"/2019 i termin od "+pocetak+" do "+kraj+"!");
            }
            
        });
        /*$.ajax({
            url : "/json/zauzeca.json",
            method: "POST",
            //contentType : "application/json",
            dataType: "text",
            data : obj,
            success : function(response){
                let kalRef = document.getElementById("kalendar");
                let sala = document.getElementById("sala").value;
                let pocetak = document.getElementById("pocetak").value;
                let kraj = document.getElementById("kraj").value;
                Pozivi.ucitajZauzecasaServera(Kalendar.ucitajPodatke);
                osvjezi(kalRef, sala, pocetak, kraj);
            },
            error : function(response){
                alert("Nije moguće rezervisati salu "+naziv+" za navedeni datum "+dan+"/"+(mjesec+1)+"/2019 i termin od "+pocetak+" do "+kraj+"!");
            }
            
        });*/
        
    }
    function ucitajPrethodneSlikeImp(prva){
        prva = prva.split("http://localhost:8080/").pop();
        var offset = slike.indexOf(prva);
        if(offset >2){
            $("#galerija div").each(function(index){
                $(this).empty();
                $(this).append("<img src="+slike[offset-3+index]+">");
            });
        }
    }
    function ucitajSlikeImpl(prva){

       //poziva sinhrono iako je nepreporucljivo da ne bi dohvatio 3 puta istu sliku, mozda ispravim
        var offset = -1;
        if(slike.length != 0){
            prva = prva.split("http://localhost:8080/").pop();
            offset = slike.indexOf(prva);
        }

        if(slike.length == 0 || offset >= slike.length-3){
            for(var i = 0; i < 3; i++){
                $.ajax({
                    url: "/slike",
                    method: "GET",
                    dataType: "text",
                    async: false,
                    data: {broj: slike.length},
                    success : function(data, status){
                        if(data != ""){
                            slike.push("slike/"+data);
                        }
                        else{
                            slike.push("");
                        }
                    }
                })
                if(i==0 && slike[slike.length-1] == ""){
                    slike.pop();
                    return;
                }
            }
            //dodavanje slika u div elemente
            $("#galerija div").each(function(index){
                $(this).empty();
                if(slike[slike.length-(3-index)] != "") $(this).append("<img src="+slike[slike.length-(3-index)]+">");
            });
        }
        else{
            //console.log(offset);
            $("#galerija div").each(function(index){
                $(this).empty();
                if(slike[offset+3+index] != "") $(this).append("<img src="+slike[offset+3+index]+">");
            });
        }
        
    }
    function ucitajOsobljeImpl(selectOsobljaRef){
        //ajax poziv koji dohvata slistu svog osoblja za select
        $.ajax({
            url:"/osoblje",
            method:"GET",
            dataType: "json",
            success : function(data, status){
                if(data.length != 0){
                    data.forEach(function(k){
                        //dodavanje novih izbora u select
                        var option = document.createElement("option");    
                        var naziv = k.ime+" "+k.prezime;
                        option.value = naziv;
                        option.innerHTML = naziv;
                        selectOsobljaRef.appendChild(option);
                    })
                }
            },
            error : function(response){
                console.log("Ajax error: "+response.message);
            }
        })
    }
    function ucitajLokacijuOsobljaImpl(tabelaOsobljaRef){
        //ocisti stare podatke
        tabelaOsobljaRef.innerHTML = "";
        //Header row kreiranje
        let osoba = document.createElement("th");        
        let sala = document.createElement("th");        
        let header = document.createElement("tr");
        osoba.innerHTML = "Osoba";
        sala.innerHTML = "Sala";
        header.appendChild(osoba);
        header.appendChild(sala);
        tabelaOsobljaRef.appendChild(header);

        //dobavi podatke iz baze
        $.ajax({
            url:"/lokacijaOsoblja",
            method: "GET",
            dataType: "json",
            success: function(data, status){
                data.forEach(function(element){
                    //kreiranje novog elementa za ubacivanje u tabelu
                    let row = document.createElement("tr");
                    let data1 = document.createElement("td");
                    let data2 = document.createElement("td");
                    data1.innerHTML = element.osoba;
                    data2.innerHTML = element.sala;
                    row.appendChild(data1);
                    row.appendChild(data2);
                    tabelaOsobljaRef.appendChild(row);
                })
            },
            error: function(data, status){
                console.log(data+"-"+status);
            }

        })
    }
    return {
        ucitajZauzecasaServera : ucitajZauzecasaServeraImpl,
        ucitajSlike : ucitajSlikeImpl,
        ucitajPrethodneSlike : ucitajPrethodneSlikeImp,
        rezervisiTermin : rezervisiTerminImpl,
        ucitajOsoblje: ucitajOsobljeImpl,
        ucitajLokacijuOsoblja: ucitajLokacijuOsobljaImpl
    }
}());
