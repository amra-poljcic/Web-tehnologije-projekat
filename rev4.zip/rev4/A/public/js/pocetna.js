Pozivi.ucitajSlike("");

prethodneSlike.addEventListener("click", event=>{
    var slika = document.getElementById("galerija").children[0].children[0].src;
    Pozivi.ucitajPrethodneSlike(slika);

});

sljedeceSlike.addEventListener("click", event=>{
    var slika = document.getElementById("galerija").children[0].children[0].src;
    Pozivi.ucitajSlike(slika);
})