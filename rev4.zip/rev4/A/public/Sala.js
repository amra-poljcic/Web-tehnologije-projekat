const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes){
    const Sala = sequelize.define("Sala", {
        id:{ 
            type:Sequelize.INTEGER,
            primaryKey:true,
            autoIncrement:true
        },//PK
        naziv:Sequelize.STRING,
        zaduzenaOsoba:{ 
            type:Sequelize.INTEGER,
            references:{
                model:"Osoblje",
                key:"id"
            }
        } //FK
    },
    {freezeTableName: true});

    return Sala;
}